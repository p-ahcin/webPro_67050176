# MiniShop Dashboard

งานข้อสอบปฏิบัติปลายภาค Web Programming รหัสนักศึกษา 67050176 พัฒนาจาก `minishop-dashboard_v1` ด้วย React, Vite, React Router, Tailwind CSS และ DaisyUI

## เริ่มใช้งาน

ใช้ Node.js `^20.19.0` หรือ `>=22.12.0` และ npm

```powershell
cd minishop-dashboard
npm ci
npm run dev
```

เปิด URL จาก Terminal หากมาจากโฟลเดอร์ราก repository ใช้ `cd 67050176_final/minishop-dashboard` ก่อน ไม่ต้องรัน JSON Server

```powershell
npm run build
npm run preview
```

## เทียบกับข้อสอบ

| ข้อ | การทำงาน | ไฟล์หลัก |
| --- | --- | --- |
| 1.1 | React/Vite ชื่อ minishop-dashboard, title MiniShop Dashboard | package.json, index.html |
| 1.2 | Semantic layout, Home/Detail/Cart/Profile/Admin และ component แยก | App.jsx, components/Layout.jsx, pages/ |
| 2.1 | สินค้าเริ่มต้น 5 รายการ, map, name/category/price/stock, สถานะ | sampleProducts.js, components/ProductUI.jsx |
| 2.2 | Responsive 1/2/3 คอลัมน์ | pages/Products.jsx, pages/Home.jsx |
| 2.3 | จำนวนสินค้า, ผลรวม price×stock, จำนวนหมดสต็อก | components/ProductUI.jsx: SummaryCards |
| 3.1 | useState + onChange + filter + toLowerCase | pages/Products.jsx |
| 3.2 | All Categories, Accessories, Display, Camera และหมวดหมู่จาก API | pages/Products.jsx |
| 3.3 | เพิ่มสินค้าใน State, validation, แสดงใหม่ทันที | components/ProductForm.jsx, context/ShopContext.jsx |
| 4.1 | useEffect + async/await + fetch + State + fallback | service/productApi.js, context/ShopContext.jsx |
| 4.2 | Loading products..., Error, Success, Retry | components/ProductUI.jsx: DataStatus |
| 4.3 | Delete ผ่าน React State แล้วสรุปเปลี่ยนทันที | context/ShopContext.jsx, pages/Products.jsx |
| 5.1 | Routes และ NavLink ไม่ reload หน้า | App.jsx, components/Layout.jsx |
| 5.2 | สี/spacing, hover, transition, empty state, labels, mobile, dark mode | style.css และ components/pages |

พาธ source ในตารางเริ่มจาก `src/` เว้น package.json และ index.html

## หน้าเว็บ

| URL | หน้าที่ |
| --- | --- |
| / | Banner, หมวดหมู่, Featured Products, สรุปสินค้า |
| /products | หน้าร้านสำหรับค้นหา กรอง ดูรายละเอียด และเลือกซื้อ |
| /products/:id | รูป รายละเอียด ราคา รีวิว สต็อก |
| /cart | ปรับจำนวน ลบ สรุปยอด สั่งซื้อจำลอง |
| /profile | ข้อมูลผู้ใช้ ฟอร์มแก้ไข ประวัติคำสั่งซื้อ |
| /admin/dashboard | สรุปสินค้า กราฟสต็อก ยอดขายและคำสั่งซื้อจำลอง |
| /admin/products | หน้าจัดการสินค้า เพิ่ม แก้ไข และลบ |
| /about | เกี่ยวกับแอปและการใช้ข้อมูล |
| URL อื่น | 404 |

## แหล่งข้อมูลและขอบเขต

API: https://fakestoreapi.com/products — แปลง title เป็น name และเติม stock จำลองเพราะ endpoint ไม่มีฟิลด์นี้ ค่า rating อ่านจาก rate/count รูปจาก image ส่วน mock/สินค้าใหม่ใช้ภาพแทน หาก API ไม่สำเร็จหรือใช้เวลาเกิน 10 วินาทีจะแจ้งเตือนและใช้ mock ตามโจทย์ กดปุ่มใช้ข้อมูลตามข้อสอบเพื่อสาธิตชุดข้อมูล 5 รายการได้

ราคาจาก API ใช้ตัวเลขเดิมในหน่วยบาทเพื่อฝึก ไม่มีการแปลงสกุลเงิน การเพิ่ม/แก้ไข/ลบเป็น State ภายในแอป ไม่เขียน Fake Store API การโหลด API ใหม่หรือเลือก mock จะตั้งรายการสินค้าและตะกร้าใหม่ แต่ไม่ลบประวัติคำสั่งซื้อในรอบนั้น

ข้อมูลใน State อยู่ตลอดการเปลี่ยนหน้า แต่เริ่มใหม่เมื่อ refresh ไม่มี login หรือชำระเงินจริง คำสั่งซื้อจำลองจะหัก stock และไปปรากฏ Profile/Admin ค่าธีมเก็บใน localStorage

## Checklist ก่อนส่ง

1. เปิดใน VS Code และรัน dev ได้ เห็น MiniShop Dashboard
2. เลือกข้อมูลตามข้อสอบ: สินค้า 5, มูลค่า 46,420.00 บาท, หมด 1
3. ค้น WIRELESS พบ Mouse; กรอง Camera พบ Webcam; ผสมคำค้นกับหมวดหมู่ต้องใช้เงื่อนไขทั้งคู่
4. เข้า Admin → Manage Products แล้วกรอกฟอร์มว่าง/ราคาติดลบ/stock ทศนิยม ต้องถูกปฏิเสธ แต่ stock = 0 ใช้ได้
5. เพิ่ม Camera ราคา 100 stock 2: สินค้า 6, มูลค่า 46,620; ลบกลับเป็น 5 และ 46,420
6. Add to Cart ของ USB-C Hub ต้องกดไม่ได้; ปรับจำนวนตะกร้าได้ไม่เกิน stock
7. สั่งซื้อจำลอง: ตะกร้าว่าง stock ลด ยอดขาย/คำสั่งซื้อใน Admin และ Profile ตรงกัน
8. ใช้ DevTools Offline แล้วโหลด API ใหม่: เห็น Loading, ข้อผิดพลาด และข้อมูล mock; กลับ Online แล้ว retry ได้
9. ตรวจ Home, Products, About และหน้าที่เหลือบนมือถือ/เดสก์ท็อป; dark mode จำค่าหลัง refresh
10. npm run build ผ่าน และแตก ZIP แล้ว npm ci / npm run dev ได้

ก่อนส่งตรวจชื่อโฟลเดอร์ตามที่อาจารย์กำหนด โจทย์เดิมระบุ `finalWebxxxx` ซึ่งสำหรับรหัส 67050176 คือ `finalWeb0176` การเปลี่ยนชื่อโฟลเดอร์ชั้นนอกไม่มีผลต่อการรัน แต่ต้องรันคำสั่ง npm ภายในโฟลเดอร์ `minishop-dashboard` ที่มี package.json
